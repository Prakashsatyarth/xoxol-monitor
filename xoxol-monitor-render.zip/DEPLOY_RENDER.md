# 🚀 Deploy to Render.com (FREE 24/7)

## Step-by-Step (2 Minutes Mein Ho Jayega!)

### Step 1: GitHub Repository Banayein
```bash
# Apne code ko GitHub pe push karo
git init
git add .
git commit -m "Initial commit"
# GitHub repo banao, then:
git remote add origin https://github.com/YOUR_USERNAME/xoxol-monitor.git
git push -u origin main
```

### Step 2: Render.com Pe Deploy
1. **https://render.com** jao
2. **"New +"** button click karo → **"Background Worker"**
3. **GitHub** connect karo → Apna repo select karo
4. Settings:
   - **Name:** `xoxol-website-monitor`
   - **Runtime:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python website_monitor.py`
   - **Plan:** `Free`

### Step 3: Environment Variables Set Karo
**Render Dashboard → Your Service → Environment**

Add these:
```
TELEGRAM_BOT_TOKEN = 123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_CHAT_ID = 123456789
```

### Step 4: Deploy!
**Manual Deploy → Deploy Latest Commit**

Bas! 🎉 Ab ye **24/7 Render ke servers pe chalega**, aapke laptop ki zaroorat nahi!

---

## 🔧 Alternative: One-Click Deploy Button

Agar aapne GitHub repo bana li, toh README mein yeh button add karo:

```markdown
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR_USERNAME/xoxol-monitor)
```

---

## 📱 Telegram Setup (Pehle Yeh Karo!)

### 1. Bot Token Lena:
1. Telegram kholiye
2. Search karo: `@BotFather`
3. Message karo: `/newbot`
4. Bot ka naam do (e.g., `XoxolMonitor`)
5. Username do (e.g., `xoxol_monitor_bot`)
6. **Token** milega - usko copy karo

### 2. Chat ID Lena:
1. Telegram search: `@userinfobot`
2. Start karo
3. Aapka **Chat ID** dikhayega (e.g., `123456789`)

---

## ✅ Verify It's Working

### Check Logs:
Render Dashboard → Your Service → **Logs**

Aapko dikhega:
```
🤖 XOXOL337 WEBSITE MONITOR - BLACK ORCHID ACTIVE
============================================================
🎯 Target: https://stashpatrck.cc/...
⏱️  Check interval: 300 seconds
📱 Telegram: ✅ Configured
============================================================
```

### Telegram Pe Test:
Bot ko message karo `/start` ya kuch bhi

---

## 🔄 Monitor Status Check

| Status | Meaning |
|--------|---------|
| 🟢 Live | Running perfectly |
| 🟡 Deploying | Starting up |
| 🔴 Failed | Check logs for error |

---

## 🆓 Free Tier Limits
- **Always On:** 750 hours/month (enough for 24/7!)
- **Restarts:** 15 min inactivity pe sleep, phir auto-restart
- **Logs:** 100 lines retain hoti hain

**Note:** Free tier pe 15 min idle ke baad sleep ho jaata hai, but monitor har 5 min mein check karta hai toh **sleep nahi hoga!** ✅

---

## 🛠️ Troubleshooting

### Error: "TELEGRAM_BOT_TOKEN not set"
**Solution:** Environment variables check karo, syntax sahi hai?

### Error: "Module not found"
**Solution:** `requirements.txt` sahi jagah pe hai? Re-deploy karo.

### Bot message nahi bhej raha
**Solution:** 
1. Bot ko kisi group ya chat mein add karo
2. BotFather pe jaake `/setprivacy` → `Disable` karo
3. Chat ID sahi hai? (number hai, username nahi)

---

**XOXOL337 — BLACK ORCHARD AWAKENED** 🐕‍🦺

Aapka monitor ab **cloud pe 24/7** chalega! 🔥
