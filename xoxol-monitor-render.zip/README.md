# 🤖 XOXOL337 Website Monitor

**Monitors website for username, password, secret_key changes and sends instant Telegram alerts.**

## Features
- 🔍 Checks website every 5 minutes (configurable)
- 📱 Instant Telegram notifications on any change
- 💾 Saves state locally to detect only real changes
- 🎯 Focused on: `username`, `password`, `secret_key`
- 🔄 Auto-retry on network errors

## Quick Start

### 1. Setup
```bash
chmod +x setup.sh
./setup.sh
```

### 2. Configure Telegram
Edit `.env` file:
```
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here
```

**Get Bot Token:**
1. Telegram → Search `@BotFather`
2. Send: `/newbot`
3. Name your bot
4. Copy the token (looks like: `123456789:ABCdef...`)

**Get Chat ID:**
1. Telegram → Search `@userinfobot`
2. Click Start
3. Copy your ID (looks like: `123456789`)

### 3. Run
```bash
python3 website_monitor.py
```

## Output
```
🤖 XOXOL337 WEBSITE MONITOR - BLACK ORCHID ACTIVE
============================================================
🎯 Target: https://stashpatrck.cc/...
⏱️  Check interval: 300 seconds
💾 State file: monitor_state.json
📱 Telegram: ✅ Configured
============================================================

[+] Starting initial fetch...
[+] Current values found:
    Username: john_doe
    Password: secret123
    Secret Key: abc-def-ghi

[+] Monitor running... Press Ctrl+C to stop

[22:45:01] Checking for updates...
[+] No changes detected
[22:50:01] Checking for updates...
[+] CHANGES DETECTED!
    • password: secret123 → newpass456
```

## Telegram Message Format
```
🔄 UPDATE DETECTED!

🔗 URL: https://stashpatrck.cc/...
🕐 Time: 2024-01-15 22:50:01

👤 Username: john_doe
🔐 Password: newpass456
🔑 Secret Key: xyz-123-abc

🤖 XOXOL337 MONITOR
```

## 🔄 24/7 Auto-Run Options (Pick One)

### Option 1: Simple Background (Easiest) ⭐
```bash
# Start (runs even after terminal closes)
chmod +x run_background.sh
./run_background.sh

# View logs
tail -f monitor.log

# Stop
./stop_monitor.sh
```

### Option 2: PM2 (Best for long-term) 🚀
```bash
# Install PM2
npm install -g pm2

# Start as service
pm2 start website_monitor.py --name "xoxol-monitor" --interpreter python3

# Auto-start on boot
pm2 startup
pm2 save

# Commands
pm2 status              # View status
pm2 logs xoxol-monitor  # View logs
pm2 stop xoxol-monitor # Stop
pm2 restart xoxol-monitor # Restart
```

### Option 3: Systemd Service (Linux)
```bash
chmod +x install_service.sh
sudo ./install_service.sh

# Then edit and add your credentials:
sudo nano /etc/systemd/system/xoxol-monitor.service
# Change: Environment="TELEGRAM_BOT_TOKEN=..."

sudo systemctl daemon-reload
sudo systemctl start xoxol-monitor
sudo systemctl status xoxol-monitor
```

### Option 4: Mac LaunchAgent (MacOS)
```bash
chmod +x install_mac_service.sh
./install_mac_service.sh

# Edit plist and add credentials:
nano ~/Library/LaunchAgents/com.xoxol.monitor.plist
# Replace YOUR_BOT_TOKEN_HERE and YOUR_CHAT_ID_HERE

# Reload
launchctl unload ~/Library/LaunchAgents/com.xoxol.monitor.plist
launchctl load ~/Library/LaunchAgents/com.xoxol.monitor.plist
```

### Option 5: Docker (Most Isolated) 🐳
```bash
# Create .env file
cat > .env << EOF
TELEGRAM_BOT_TOKEN=your_token
TELEGRAM_CHAT_ID=your_chat_id
EOF

# Run
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

### Option 6: Tmux/Screen (Manual)
```bash
tmux new -s monitor
python3 website_monitor.py
# Ctrl+B, then D to detach
tmux attach -t monitor  # Reconnect
```

## Configuration

Edit these in `website_monitor.py`:
```python
URL = "https://stashpatrck.cc/error.php?..."
CHECK_INTERVAL = 300  # seconds (5 minutes)
```

---
**XOXOL337 — BLACK ORCHARD AWAKENED** 🐕‍🦺
